module.exports = {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: { DEFAULT: "#1EC7C0", 500:"#1EC7C0" },
        orange: { 500: "#f97316", 600:"#ea580c" },
        cyan: { 400: "#22d3ee", 500:"#06b6d4" }
      },
      boxShadow: { 'soft': '0 10px 30px -10px rgba(30,199,192,0.35)' },
      fontFamily: { sans: ['-apple-system','BlinkMacSystemFont','Segoe UI','Roboto','sans-serif'] },
      animation: {
        pulse: 'pulse 2s cubic-bezier(0.4,0,0.6,1) infinite',
        spin: 'spin 1s linear infinite'
      }
    },
  },
  plugins: []
};
