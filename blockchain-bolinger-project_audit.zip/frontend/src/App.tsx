import React, { useEffect, useState } from 'react'
import { TrendingUp, TrendingDown, Bot, Newspaper, Coins, Menu, LogIn, LogOut } from 'lucide-react'
import { getTopCoins, getNews } from './services/api/CryptoAPI'
import PortfolioTab from './components/features/PortfolioTab'
import TradesTab from './components/features/TradesTab'
import AuditTab from './components/features/AuditTab'
import { useAuth } from './contexts/AuthContext'

type Coin = { id: string; symbol: string; name: string; image: string; current_price: number; price_change_percentage_24h: number }
type NewsItem = { title: string; url: string; source: string }

function AuthBar(){
  const { user, logout, login, register } = useAuth()
  const [email,setEmail] = React.useState('')
  const [pw,setPw] = React.useState('')
  return (
    <div className='flex items-center gap-3'>
      {user ? (<>
        <span className='text-sm text-slate-300'>Hallo, {user.email}</span>
        <button className='btn' onClick={logout}><LogOut size={16}/> Logout</button>
      </>) : (
        <div className='flex items-center gap-2'>
          <input className='bg-slate-800 text-white rounded-xl p-2' placeholder='E-Mail' value={email} onChange={e=>setEmail(e.target.value)} />
          <input className='bg-slate-800 text-white rounded-xl p-2' type='password' placeholder='Passwort' value={pw} onChange={e=>setPw(e.target.value)} />
          <button className='btn' onClick={()=>login(email,pw)}><LogIn size={16}/> Login</button>
          <button className='btn' onClick={()=>register(email,pw)}>Registrieren</button>
        </div>
      )}
    </div>
  )
}

export default function App() {
  const [coins, setCoins] = useState<Coin[]>([])
  const [news, setNews] = useState<NewsItem[]>([])
  const [loading, setLoading] = useState(true)
  const [showPortfolio, setShowPortfolio] = useState(false)
  const [showTrades, setShowTrades] = useState(false)
  const [showAudit, setShowAudit] = useState(false)

  useEffect(() => {
    ;(async () => {
      try {
        const [c, n] = await Promise.all([getTopCoins(), getNews()])
        setCoins(c); setNews(n)
      } finally { setLoading(false) }
    })()
  }, [])

  return (
    <div className="min-h-screen pb-20">
      <header className="sticky top-0 z-10 bg-slate-950/80 backdrop-blur border-b border-slate-800">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Coins className="text-primary" />
            <h1 className="text-xl font-bold">Blockchain-Bolinger</h1>
          </div>
          <AuthBar />
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6 grid md:grid-cols-3 gap-6">
        <section className="md:col-span-2 card p-4">
          <h2 className="text-lg font-semibold mb-3 flex items-center gap-2"><TrendingUp/> Top Coins (24h)</h2>
          {loading ? <p>Lade Kurse…</p> : (
            <ul className="divide-y divide-slate-800">
              {coins.map(c => (
                <li key={c.id} className="py-3 flex items-center gap-3">
                  <img src={c.image} alt={c.symbol} className="w-7 h-7 rounded-full"/>
                  <div className="flex-1">
                    <div className="font-medium">{c.name} <span className="text-slate-400">({c.symbol.toUpperCase()})</span></div>
                    <div className="text-sm text-slate-400">€ {c.current_price.toLocaleString('de-DE')}</div>
                  </div>
                  <div className={
                    'text-sm font-semibold flex items-center gap-1 ' +
                    (c.price_change_percentage_24h >= 0 ? 'text-emerald-400' : 'text-rose-400')
                  }>
                    {c.price_change_percentage_24h >= 0 ? <TrendingUp size={16}/> : <TrendingDown size={16}/>}
                    {c.price_change_percentage_24h.toFixed(2)}%
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card p-4">
          <h2 className="text-lg font-semibold mb-3 flex items-center gap-2"><Newspaper/> News</h2>
          {loading ? <p>Lade News…</p> : (
            <ul className="space-y-3">
              {news.map((n,i) => (
                <li key={i}>
                  <a href={n.url} target="_blank" className="hover:underline text-slate-100">{n.title}</a>
                  <div className="text-xs text-slate-400">{n.source}</div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="md:col-span-3 card p-4">
          <h2 className="text-lg font-semibold mb-3 flex items-center gap-2"><Bot/> AI-Insights</h2>
          <p className="text-slate-300 mb-3">Heuristische Marktanalyse vom Backend (<code>/api/ai/insights</code>).</p>
          <div className="flex gap-3">
            <button className="btn" onClick={()=>setShowPortfolio(s=>!s)}>{showPortfolio ? 'Portfolio verbergen' : 'Portfolio öffnen'}</button>
            <button className="btn" onClick={()=>setShowTrades(s=>!s)}>{showTrades ? 'Trades verbergen' : 'Trades öffnen'}</button>
            <button className="btn" onClick={()=>setShowAudit(s=>!s)}>{showAudit ? 'Audit verbergen' : 'Audit öffnen'}</button>
          </div>
        </section>

        {showPortfolio && (
          <section className="md:col-span-3">
            <PortfolioTab/>
          </section>
        )}

        {showTrades && (
          <section className="md:col-span-3">
            <TradesTab/>
          </section>
        )}

        {showAudit && (
          <section className="md:col-span-3">
            <AuditTab/>
          </section>
        )}
      </main>

      <nav className="nav">
        <div className="max-w-5xl mx-auto px-4 py-3 grid grid-cols-5 gap-2 text-center text-xs">
          <a className="text-primary">News</a>
          <a>Kurse</a>
          <a>Kaufen</a>
          <a>Über</a>
          <a>Mehr</a>
        </div>
      </nav>
    </div>
  )
}
