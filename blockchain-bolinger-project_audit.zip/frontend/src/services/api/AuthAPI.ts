const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

async function refresh(){
  const r = await fetch(`${API}/auth/refresh`, { method:'POST', credentials: 'include' })
  if(!r.ok) throw new Error('refresh_failed')
  const { token } = await r.json()
  localStorage.setItem('bb_token', token)
  return token
}

export async function fetchWithAuth(path:string, method='GET', body?:any){
  let token = localStorage.getItem('bb_token')
  const headers: Record<string,string> = { 'Content-Type': 'application/json' }
  if(token) headers['Authorization'] = 'Bearer ' + token
  let r = await fetch(`${API}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined, credentials: 'include' })
  if(r.status === 401){
    try {
      token = await refresh()
      headers['Authorization'] = 'Bearer ' + token
      r = await fetch(`${API}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined, credentials: 'include' })
    } catch {
      // pass through 401
    }
  }
  if(!r.ok) throw new Error('request_failed')
  return r.json()
}
