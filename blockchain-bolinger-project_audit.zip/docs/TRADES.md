# Trades, Cost-Basis & PnL

## Endpoints
- **GET** `/api/trades` – Liste der Trades (usergebunden)
- **POST** `/api/trades` – { coinId, symbol, side: BUY|SELL, quantity, price, fee?, ts? }
- **DELETE** `/api/trades/:id`
- **GET** `/api/trades/positions/avg` – Durchschnittlicher Einstand je Coin (AVG-Methode)
- **GET** `/api/trades/pnl/history` – Tägliche PnL-Kurve (90 Tage) basierend auf AVG und Marktpreisen

## Hinweise
- **AVG** statt FIFO für einfache PnL-Berechnung (FIFO kann leicht ergänzt werden).
- Preise via **CoinGecko market_chart** (EUR) – 90 Tage, in-memory Cache (5 Min.).


## CSV Import / Export
- **Import**: `POST /api/trades/import` (multipart/form-data, file field `file`), CSV headers: `side,coinId,symbol,quantity,price,fee,ts`
- **Export**: `GET /api/trades/export` returns `trades_export.csv`

## Cost Methods
- `AVG` (existing) and `FIFO` (new) supported.
- Use `GET /api/trades/positions?method=fifo` for FIFO positions (includes realized PnL per coin).


## CSV Validation
- Import validates each row; returns `errors` array with `{ row, errors }` objects describing issues per CSV row.
- Required columns: `side,coinId,quantity,price` (symbol optional, fee optional, ts optional).


## CSV Preview
- Use `/api/trades/import?preview=true` to parse and validate CSV without writing. Frontend shows a preview modal; confirm to commit import.


## CSV Preview Editing & Rollback
- Preview modal allows inline editing of rows (side, coinId, quantity, price, fee). Confirming sends edited rows to `POST /api/trades/import/json` and returns `batchId` for the import.
- To undo an import: `POST /api/trades/import/rollback/:batchId` will delete trades created in that batch.
- Errors can be downloaded as CSV via the "Fehler herunterladen" button in the preview modal (client-side CSV generation).


## Audit Log
- All important actions (auth register/login/refresh/logout, trade create/delete, import commit/rollback) are logged to `AuditLog`.
- Endpoint `GET /api/audit` returns the current user's audit entries (default limit 100).
