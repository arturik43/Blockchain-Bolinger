# Prisma & Datenbank-Setup

## Lokal (ohne Docker)
1) Starte eine Postgres DB (z. B. via Docker Desktop) oder nutze eine vorhandene.
2) Setze `DATABASE_URL` in `backend/.env`, z. B.:
```
DATABASE_URL=postgresql://bb_user:bb_pass@localhost:5432/bb_db?schema=public
```
3) Erzeuge Client & Migration:
```bash
cd backend
npx prisma generate
npx prisma migrate dev --name init
```
4) (Optional) Öffne Prisma Studio:
```bash
npm run prisma:studio
```

## Mit Docker-Compose
```bash
cd docker
docker compose up -d db
# Erzeuge Prisma Client & Migration im Backend-Container (einmalig)
docker compose exec backend npx prisma generate
docker compose exec backend npx prisma migrate dev --name init
```
