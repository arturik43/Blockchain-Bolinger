import { Router } from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { prisma } from '../utils/prisma.js'
import crypto from 'crypto'
import { logAudit } from '../utils/audit.js'

const r = Router()

function signAccess(user){
  return jwt.sign({ sub: user.id, email: user.email }, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '15m' })
}
function makeRefreshToken(){
  return crypto.randomBytes(48).toString('hex')
}

function setRefreshCookie(res, token){
  res.cookie('bb_refresh', token, {
    httpOnly: true, secure: false, sameSite: 'lax', path: '/api/auth/refresh', maxAge: 7*24*60*60*1000
  })
}

r.post('/register', async (req, res) => {
  const { email, password } = req.body || {}
  if(!email || !password) return res.status(400).json({ error: 'missing_fields' })
  const exists = await prisma.user.findUnique({ where: { email: email.toLowerCase() } })
  if(exists) return res.status(409).json({ error: 'email_exists' })
  const hash = await bcrypt.hash(password, 10)
  const user = await prisma.user.create({ data: { email: email.toLowerCase(), password: hash } })
  const access = signAccess(user)
  const refresh = makeRefreshToken()
  const expiresAt = new Date(Date.now() + 7*24*60*60*1000)
  await prisma.refreshToken.create({ data: { userId: user.id, token: refresh, expiresAt } })
  setRefreshCookie(res, refresh)
  await logAudit(user.id, 'auth.register', { email: user.email }, req.ip)
  res.json({ token: access, user: { id: user.id, email: user.email } })
})

r.post('/login', async (req, res) => {
  const { email, password } = req.body || {}
  const user = await prisma.user.findUnique({ where: { email: (email||'').toLowerCase() } })
  if(!user) return res.status(401).json({ error: 'invalid_credentials' })
  const ok = await bcrypt.compare(password, user.password)
  if(!ok) return res.status(401).json({ error: 'invalid_credentials' })
  const access = signAccess(user)
  const refresh = makeRefreshToken()
  const expiresAt = new Date(Date.now() + 7*24*60*60*1000)
  await prisma.refreshToken.create({ data: { userId: user.id, token: refresh, expiresAt } })
  setRefreshCookie(res, refresh)
  await logAudit(user.id, 'auth.register', { email: user.email }, req.ip)
  res.json({ token: access, user: { id: user.id, email: user.email } })
})

r.post('/refresh', async (req, res) => {
  const token = req.cookies?.bb_refresh
  if(!token) return res.status(401).json({ error: 'missing_refresh' })
  const rec = await prisma.refreshToken.findUnique({ where: { token } })
  if(!rec || rec.expiresAt < new Date()) return res.status(401).json({ error: 'invalid_refresh' })
  // rotate
  await prisma.refreshToken.delete({ where: { token } })
  const user = await prisma.user.findUnique({ where: { id: rec.userId } })
  const access = signAccess(user)
  const next = makeRefreshToken()
  const expiresAt = new Date(Date.now() + 7*24*60*60*1000)
  await prisma.refreshToken.create({ data: { userId: user.id, token: next, expiresAt } })
  setRefreshCookie(res, next)
  await logAudit(user.id, 'auth.refresh', {}, req.ip)
  res.json({ token: access })
})

r.post('/logout', async (req, res) => {
  const token = req.cookies?.bb_refresh
  if(token){
    await prisma.refreshToken.delete({ where: { token } }).catch(()=>null)
    res.clearCookie('bb_refresh', { path: '/api/auth/refresh' })
    await logAudit(null, 'auth.logout', { token }, req.ip)
  }
  res.json({ ok: true })
})

export default r
