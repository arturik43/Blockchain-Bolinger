import { readJSON, writeJSON } from 'fs-extra'
const usersFile = new URL('../data/users.json', import.meta.url).pathname
const portfoliosFile = new URL('../data/portfolios.json', import.meta.url).pathname

export async function getUsers(){ try { return await readJSON(usersFile) } catch { return [] } }
export async function saveUsers(users){ await writeJSON(usersFile, users, { spaces: 2 }) }

export async function getPortfolios(){ try { return await readJSON(portfoliosFile) } catch { return [] } }
export async function savePortfolios(items){ await writeJSON(portfoliosFile, items, { spaces: 2 }) }
