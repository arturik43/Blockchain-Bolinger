import express from 'express'
import cors from 'cors'
import cookieParser from 'cookie-parser'
import dotenv from 'dotenv'
import helmet from 'helmet'
import morgan from 'morgan'
import { createServer } from 'http'
import { Server as SocketIOServer } from 'socket.io'
import cryptoRouter from './src/routes/crypto.js'
import newsRouter from './src/routes/news.js'
import aiRouter from './src/routes/ai.js'
import authRouter from './src/routes/auth.js'
import portfolioRouter from './src/routes/portfolio.js'
import tradesRouter from './src/routes/trades.js'
import auditRouter from './src/routes/audit.js'

dotenv.config()
const app = express()
const httpServer = createServer(app)
const io = new SocketIOServer(httpServer, { cors: { origin: process.env.CORS_ORIGIN || '*' } })

app.use(helmet())
app.use(cookieParser())
app.use(express.json())
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || '*', credentials: true }))
app.use(morgan('dev'))

app.get('/api/health', (_req, res) => res.json({ ok: true }))

app.use('/api/crypto', cryptoRouter)
app.use('/api/news', newsRouter)
app.use('/api/ai', aiRouter)
app.use('/api/auth', authRouter)
app.use('/api/portfolio', portfolioRouter)
app.use('/api/trades', tradesRouter)
app.use('/api/audit', auditRouter)

io.on('connection', socket => {
  socket.emit('hello', { msg: 'Willkommen bei Blockchain-Bolinger WS' })
})

const port = process.env.PORT || 5000
httpServer.listen(port, () => {
  console.log('API listening on http://localhost:' + port)
})
