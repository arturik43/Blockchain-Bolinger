
# Deployment & CI

## GitHub Actions
Two workflows are added:
- `.github/workflows/ci.yml` — runs on PRs and pushes to `main`. It sets up Postgres service, runs Prisma generate & migrations (deploy) and builds frontend.
- `.github/workflows/deploy.yml` — runs on push to `main`, builds Docker images and pushes to Docker Hub. Optionally SSH-deploys to a remote host (configure secrets).

## Required GitHub Secrets for deploy.yml
- DOCKERHUB_USERNAME
- DOCKERHUB_TOKEN
- DOCKERHUB_REPO (name base, e.g. 'blockchain-bolinger')
Optional (for SSH deploy):
- REMOTE_HOST
- REMOTE_USER
- REMOTE_DIR (e.g. /opt/blockchain-bolinger)
- SSH_PRIVATE_KEY
- SSH_PORT

## Local deploy with scripts/deploy.sh
Usage examples:
- Start locally via docker-compose: `./scripts/deploy.sh local`
- Build & push images to Docker Hub: `DOCKERHUB_USER=... DOCKERHUB_TOKEN=... ./scripts/deploy.sh dockerhub`
- SSH deploy: set REMOTE_HOST/REMOTE_USER/REMOTE_DIR then run `./scripts/deploy.sh ssh`

## CI Notes
- CI uses Postgres service; migrations are run with `npx prisma migrate deploy` (ensure migrations checked into repo).
- If you need seeds, add a `prisma/seed.js` script and call it after migrations in CI.
