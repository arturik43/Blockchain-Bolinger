import { fetchWithAuth } from './AuthAPI'
export type Trade = { id:string; coinId:string; symbol:string; side:'BUY'|'SELL'; quantity:number; price:number; fee:number; ts:string }
export async function listTrades(){ return await fetchWithAuth('/trades') }
export async function createTrade(t: Omit<Trade,'id'>){ return await fetchWithAuth('/trades', 'POST', t) }
export async function deleteTrade(id:string){ return await fetchWithAuth(`/trades/${id}`, 'DELETE') }
export async function avgPositions(){ return await fetchWithAuth('/trades/positions/avg') }
export async function fifoPositions(){ return await fetchWithAuth('/trades/positions?method=fifo') }
export async function pnlHistory(){ return await fetchWithAuth('/trades/pnl/history') }
export async function exportTrades(){ 
  const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'
  const token = localStorage.getItem('bb_token')
  const r = await fetch(`${API}/trades/export`, { method: 'GET', headers: { 'Authorization': token ? 'Bearer '+token : '' }, credentials: 'include' })
  if(!r.ok) throw new Error('export_failed')
  const blob = await r.blob()
  return blob
}
export async function importTrades(file: File){
  const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'
  const form = new FormData()
  form.append('file', file)
  const r = await fetch(`${API}/trades/import`, { method: 'POST', body: form, credentials: 'include' })
  if(!r.ok) throw new Error('import_failed')
  return r.json()
}
