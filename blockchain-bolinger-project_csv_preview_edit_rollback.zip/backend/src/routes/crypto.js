import { Router } from 'express'
import { getTopCoinsEUR } from '../services/prices.js'
const r = Router()

r.get('/top', async (_req, res) => {
  try {
    const data = await getTopCoinsEUR(10)
    res.json(data)
  } catch (e) {
    res.status(500).json({ error: 'coingecko_failed', detail: e?.message })
  }
})

export default r
