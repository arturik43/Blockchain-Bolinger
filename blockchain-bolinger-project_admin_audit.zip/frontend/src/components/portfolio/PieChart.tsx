import React from 'react'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts'

export default function AllocationPie({ data }:{ data: { name:string, value:number }[] }){
  const colors = ['#1EC7C0','#22d3ee','#f97316','#06b6d4','#22c55e','#a855f7','#f472b6','#fbbf24']
  return (
    <div style={{ width:'100%', height: 220 }}>
      <ResponsiveContainer>
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="name" outerRadius={80} label>
            {data.map((_, i) => <Cell key={i} />)}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}
