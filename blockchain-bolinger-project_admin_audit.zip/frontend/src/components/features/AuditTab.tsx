import React, { useEffect, useState } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { listAudit } from '../../services/api/AuditAPI'

export default function AuditTab(){
  const { user } = useAuth()
  const [logs, setLogs] = useState<any[]>([])

  useEffect(() => { if(user) load() }, [user])

  async function load(){ const data = await listAudit(200); setLogs(data || []) }

  if(!user) return <div className="card p-4 text-amber-300">Bitte einloggen, um Audit-Logs zu sehen.</div>

  return (
    <div className="px-4 py-4 pb-24">
      <h1 className="text-white text-2xl font-bold mb-6">Audit Logs</h1>
      <div className="card p-4">
        <div className="text-slate-300 mb-3">Letzte Aktionen</div>
        <ul className="divide-y divide-slate-800">
          {logs.map(l => (
            <li key={l.id} className="py-3">
              <div className="text-sm text-slate-400">{new Date(l.createdAt).toLocaleString('de-DE')}</div>
              <div className="font-medium">{l.action}</div>
              <pre className="text-xs mt-2 p-2 bg-slate-900 rounded">{JSON.stringify(l.details||{}, null, 2)}</pre>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
