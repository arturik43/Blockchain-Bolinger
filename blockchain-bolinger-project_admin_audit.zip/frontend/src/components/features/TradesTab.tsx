import React, { useEffect, useState } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { listTrades, createTrade, deleteTrade, Trade, avgPositions, pnlHistory, fifoPositions, importTrades, importTradesJson, exportTrades, rollbackImport } from '../../services/api/TradesAPI'
import { getTopCoins } from '../../services/api/CryptoAPI'
import { Trash2, Plus, LineChart } from 'lucide-react'
import { LineChart as Lc, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

type Coin = { id:string; symbol:string; name:string }

export default function TradesTab(){
  // positions-table-inserted

  const [method, setMethod] = useState<'fifo'|'avg'>('fifo')
  const [importFile, setImportFile] = useState<File | null>(null)
  const [positions, setPositions] = useState<any[]>([])
  const [importResult, setImportResult] = useState<{ created:number, errors:any[] } | null>(null)
  const [previewRows, setPreviewRows] = useState<any[] | null>(null)
  const [showPreview, setShowPreview] = useState(false)
  const [batchId, setBatchId] = useState<string | null>(null)
  const [rollbackFeedback, setRollbackFeedback] = useState<string | null>(null)

  const { user } = useAuth()
  const [trades, setTrades] = useState<Trade[]>([])
  const [coins, setCoins] = useState<Coin[]>([])
  const [form, setForm] = useState({ coinId:'', symbol:'', side:'BUY', quantity:'', price:'', fee:'' })
  const [history, setHistory] = useState<any[]>([])

  useEffect(() => { if(user){ refresh() } }, [user])
  useEffect(() => { getTopCoins().then((xs:any[]) => setCoins(xs.map(c=>({ id:c.id, symbol:c.symbol.toUpperCase(), name:c.name })))) }, [])

  async function refresh(){
    setMethod(method)

    setTrades(await listTrades())
    setHistory(await pnlHistory())
  }

  async function add(){
    const payload = {
      coinId: form.coinId,
      symbol: form.symbol,
      side: form.side as 'BUY'|'SELL',
      quantity: parseFloat(form.quantity||'0'),
      price: parseFloat(form.price||'0'),
      fee: parseFloat(form.fee||'0'),
      ts: new Date().toISOString()
    }
    await createTrade(payload)
    setForm({ coinId:'', symbol:'', side:'BUY', quantity:'', price:'', fee:'' })
    await refresh()
  }

  async function del(id:string){ await deleteTrade(id); await refresh() }

  return (
    <div className="px-4 py-4 pb-24">
      <h1 className="text-white text-2xl font-bold mb-6">Trades</h1>

      <div className="flex items-center gap-3 mb-4">
        <label className="text-slate-300">Methode:</label>
        <select className="bg-slate-800 text-white rounded-xl p-2" value={method} onChange={e=>setMethod(e.target.value as 'fifo'|'avg')}>
          <option value="fifo">FIFO</option>
          <option value="avg">AVG</option>
        </select>
        <button className="btn" onClick={refresh}>Refresh</button>
        <input type="file" accept="text/csv" onChange={e=>setImportFile(e.target.files?.[0]||null)} />
        <button className="btn" onClick={async ()=>{ if(importFile){ const res = await importTrades(importFile, true); setPreviewRows(res.preview || []); setImportResult(res); setShowPreview(true) } }}>Import CSV</button>
        <button className="btn" onClick={async ()=>{ const b = await exportTrades(); const url = URL.createObjectURL(b); const a = document.createElement('a'); a.href = url; a.download = 'trades_export.csv'; a.click(); }}>Export CSV</button>
      </div>

      {!user && <div className="card p-4 mb-4 text-amber-300">Bitte einloggen, um Trades zu verwalten.</div>}

      {user && (<>
        <div className="card p-4 mb-6">
          <div className="grid md:grid-cols-6 gap-3">
            <select className="bg-slate-800 text-white rounded-xl p-3"
              value={form.coinId}
              onChange={e=>{
                const c = coins.find(x=>x.id===e.target.value)
                setForm({ ...form, coinId: e.target.value, symbol: (c?.symbol||'') })
              }}>
              <option value="">Coin wählen…</option>
              {coins.map(c=>(<option key={c.id} value={c.id}>{c.name} ({c.symbol})</option>))}
            </select>
            <select className="bg-slate-800 text-white rounded-xl p-3" value={form.side} onChange={e=>setForm({ ...form, side:e.target.value })}>
              <option>BUY</option>
              <option>SELL</option>
            </select>
            <input className="bg-slate-800 text-white rounded-xl p-3" placeholder="Menge" value={form.quantity} onChange={e=>setForm({ ...form, quantity:e.target.value })}/>
            <input className="bg-slate-800 text-white rounded-xl p-3" placeholder="Preis (EUR)" value={form.price} onChange={e=>setForm({ ...form, price:e.target.value })}/>
            <input className="bg-slate-800 text-white rounded-xl p-3" placeholder="Fee (EUR)" value={form.fee} onChange={e=>setForm({ ...form, fee:e.target.value })}/>
            <button className="btn" onClick={add}><Plus size={16}/> Trade speichern</button>
          </div>
        </div>

        <div className="card p-4 mb-6">
          <div className="text-slate-300 mb-2 flex items-center gap-2"><LineChart/> PnL Verlauf (90 Tage)</div>
          <div style={{ width:'100%', height: 250 }}>
            <ResponsiveContainer>
              <Lc data={history.map(d=>({ t:new Date(d.t).toLocaleDateString('de-DE'), pnl: d.pnl }))}>
                <XAxis dataKey="t" hide />
                <YAxis />
                <Tooltip />
                <Line dataKey="pnl" dot={false} />
              </Lc>
            </ResponsiveContainer>
        </div>

        {/* Positions Table */}
        <div className="card p-4 mb-6">
          <div className="text-slate-300 mb-2">Positionen ({method.toUpperCase()})</div>
          {positions.length === 0 ? <div className="text-slate-500">Keine Positionen</div> : (
            <ul className="divide-y divide-slate-800">
              {positions.map(p => (
                <li key={p.coinId} className="py-3 flex items-center gap-3">
                  <div className="flex-1">
                    <div className="font-medium">{p.coinId} <span className="text-slate-400">({p.symbol||''})</span></div>
                    <div className="text-sm text-slate-400">Menge: {Number(p.amount).toFixed(6)} | Einstand: € {Number(p.entryPrice||0).toFixed(4)}</div>
                    <div className={"text-sm " + ((p.realizedPnl||0) >= 0 ? "text-emerald-400":"text-rose-400")}>
                      Realisierte PnL: € {Number(p.realizedPnl||0).toFixed(2)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Import Results */}
        {importResult && (
          <div className="card p-4 mb-6">
            <div className="text-slate-300 mb-2">Import Ergebnis</div>
            <div>Erstellt: {importResult.created}</div>
            {importResult.errors && importResult.errors.length>0 && (
              <div className="mt-3 text-sm text-rose-300">
                <div>Fehlerzeilen:</div>
                <ul className="list-disc ml-5">
                  {importResult.errors.map((e,i)=>(<li key={i}>Zeile {e.row}: {e.errors.join(', ')}</li>))}
                </ul>
              </div>
            )}
          </div>
        )}

        <div className="card p-4">
          <div className="text-slate-300 mb-2">Letzte Trades</div>
          <ul className="divide-y divide-slate-800">
            {trades.map(t => (
              <li key={t.id} className="py-3 flex items-center gap-3">
                <div className="flex-1">
                  <div className="font-medium">{t.symbol} • {t.side}</div>
                  <div className="text-sm text-slate-400">Menge {t.quantity} @ € {t.price} • Fee € {t.fee}</div>
                </div>
                <button className="text-rose-400 hover:text-rose-300" onClick={()=>del(t.id)}><Trash2/></button>
              </li>
            ))}
          </ul>
        </div>
      </>)}
    </div>
  )
}
