import { fetchWithAuth } from './AuthAPI'
export async function adminListAudit(limit=200, userId=''){ return await fetchWithAuth(`/admin/audit?limit=${limit}${userId?`&userId=${userId}`:''}`) }
export async function adminExportAudit(limit=200, userId=''){
  const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'
  const token = localStorage.getItem('bb_token')
  const url = `${API}/admin/audit?limit=${limit}${userId?`&userId=${userId}`:''}&export=csv`
  const r = await fetch(url, { method: 'GET', headers: { 'Authorization': token ? 'Bearer '+token : '' }, credentials: 'include' })
  if(!r.ok) throw new Error('export_failed')
  return await r.blob()
}
export async function adminListUsers(limit=200){ return await fetchWithAuth(`/admin/users?limit=${limit}`) }
export async function adminPromote(userId:string){ return await fetchWithAuth('/admin/promote','POST',{ userId }) } 
