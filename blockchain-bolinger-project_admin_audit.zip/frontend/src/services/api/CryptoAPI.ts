import axios from 'axios'
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'
export async function getTopCoins(){
  try {
    const { data } = await axios.get(`${API_URL}/crypto/top`)
    return data
  } catch {
    const { data } = await axios.get('https://api.coingecko.com/api/v3/coins/markets', {
      params: { vs_currency: 'eur', order: 'market_cap_desc', per_page: 10, page: 1, sparkline: false }
    })
    return data
  }
}
export async function getNews(){
  try { const { data } = await axios.get(`${API_URL}/news/top`); return data }
  catch { return [{ title:'Fallback: Krypto-News Demo 1', url:'#', source:'Demo' }] }
}
