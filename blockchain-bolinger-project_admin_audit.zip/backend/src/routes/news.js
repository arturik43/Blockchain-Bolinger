import { Router } from 'express'
import axios from 'axios'
import { getCache, setCache } from '../utils/cache.js'
const r = Router()

r.get('/top', async (_req, res) => { const hit = getCache('news_top'); if(hit) return res.json(hit);
  const key = process.env.NEWS_API_KEY
  try {
    if (key) {
      const { data } = await axios.get('https://newsapi.org/v2/top-headlines', {
        params: { category: 'business', language: 'de', pageSize: 10, apiKey: key }
      })
      const items = (data.articles || []; setCache('news_top', items, 5*60_000); res.json(items).map(a => ({ title: a.title, url: a.url, source: a.source?.name || 'NewsAPI' }))
      setCache('news_top', items, 5*60_000); return res.json(items)
    }
    const items = [
      { title: 'Fallback: Krypto-News Demo 1', url: 'https://example.com/1', source: 'Demo' },
      { title: 'Fallback: Krypto-News Demo 2', url: 'https://example.com/2', source: 'Demo' }
    ]; setCache('news_top', items, 5*60_000); res.json(items)
  } catch (e) {
    res.status(500).json({ error: 'news_failed', detail: e?.message })
  }
})

export default r
