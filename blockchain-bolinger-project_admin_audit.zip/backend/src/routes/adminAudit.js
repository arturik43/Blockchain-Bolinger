import { Router } from 'express'
import { prisma } from '../utils/prisma.js'
import { requireAuth } from '../middleware/auth.js'
import { requireAdmin } from '../middleware/admin.js'

const r = Router()

// GET /api/admin/audit?limit=100&userId=&export=csv
r.get('/audit', requireAuth, requireAdmin, async (req, res) => {
  const limit = Math.min(5000, Number(req.query.limit) || 200)
  const where = {}
  if(req.query.userId) where.userId = req.query.userId
  const logs = await prisma.auditLog.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: limit
  })
  if(String(req.query.export||'').toLowerCase() === 'csv'){
    // build CSV
    const header = ['id','userId','action','ip','createdAt','details']
    const rows = logs.map(l => [l.id, l.userId||'', l.action, l.ip||'', l.createdAt.toISOString(), JSON.stringify(l.details||{})])
    const csv = [header.join(','), ...rows.map(r=>r.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(','))].join('\n')
    res.setHeader('Content-Type', 'text/csv')
    res.setHeader('Content-Disposition', 'attachment; filename="audit_logs.csv"')
    return res.send(csv)
  }
  res.json(logs)
})

// GET /api/admin/users - list users (limit)
r.get('/users', requireAuth, requireAdmin, async (req, res) => {
  const limit = Math.min(1000, Number(req.query.limit) || 200)
  const users = await prisma.user.findMany({ take: limit, orderBy: { createdAt: 'desc' } })
  res.json(users)
})

// POST /api/admin/promote - body { userId }
r.post('/promote', requireAuth, requireAdmin, async (req, res) => {
  const { userId } = req.body || {}
  if(!userId) return res.status(400).json({ error: 'missing_userId' })
  const user = await prisma.user.update({ where: { id: userId }, data: { role: 'admin' } })
  res.json({ ok: true, user })
})

export default r
