import { Router } from 'express'
import { buildInsights } from '../services/aiAnalysisService.js'
const r = Router()
r.get('/insights', async (_req, res) => {
  const insights = await buildInsights()
  res.json(insights)
})
export default r
