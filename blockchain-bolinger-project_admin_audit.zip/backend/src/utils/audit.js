import { prisma } from './prisma.js'

export async function logAudit(userId, action, details = {}, ip = null){
  try{
    await prisma.auditLog.create({ data: { userId: userId || null, action, details: details || {}, ip: ip || null } })
  } catch(e){
    console.warn('audit-log-failed', e?.message || e)
  }
}
