export function requireAdmin(req, res, next){
  const admins = (process.env.ADMIN_EMAILS || '').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean)
  const email = (req.user && req.user.email || '').toLowerCase()
  if(admins.includes(email)) return next()
  return res.status(403).json({ error: 'forbidden' })
}