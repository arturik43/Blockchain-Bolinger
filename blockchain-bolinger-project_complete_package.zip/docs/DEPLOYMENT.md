
# Deployment & CI

## GitHub Actions
Two workflows are added:
- `.github/workflows/ci.yml` — runs on PRs and pushes to `main`. It sets up Postgres service, runs Prisma generate & migrations (deploy) and builds frontend.
- `.github/workflows/deploy.yml` — runs on push to `main`, builds Docker images and pushes to Docker Hub. Optionally SSH-deploys to a remote host (configure secrets).

## Required GitHub Secrets for deploy.yml
- DOCKERHUB_USERNAME
- DOCKERHUB_TOKEN
- DOCKERHUB_REPO (name base, e.g. 'blockchain-bolinger')
Optional (for SSH deploy):
- REMOTE_HOST
- REMOTE_USER
- REMOTE_DIR (e.g. /opt/blockchain-bolinger)
- SSH_PRIVATE_KEY
- SSH_PORT

## Local deploy with scripts/deploy.sh
Usage examples:
- Start locally via docker-compose: `./scripts/deploy.sh local`
- Build & push images to Docker Hub: `DOCKERHUB_USER=... DOCKERHUB_TOKEN=... ./scripts/deploy.sh dockerhub`
- SSH deploy: set REMOTE_HOST/REMOTE_USER/REMOTE_DIR then run `./scripts/deploy.sh ssh`

## CI Notes
- CI uses Postgres service; migrations are run with `npx prisma migrate deploy` (ensure migrations checked into repo).
- If you need seeds, add a `prisma/seed.js` script and call it after migrations in CI.


## Production Docker Compose (`docker/docker-compose.prod.yml`)

A production-ready `docker-compose` is available at `docker/docker-compose.prod.yml`. It defines:
- `db` (Postgres) with persistent volume and healthcheck
- `backend` built from `backend` Dockerfile, uses `backend/.env` via `env_file`
- `frontend` built from `frontend` Dockerfile
- optional `nginx` reverse-proxy (reads `docker/nginx.conf`) — this expects the frontend build to output static files into a volume path `frontend_static`

### How to use (simple):
1. Provide production environment values in `backend/.env` (or in a secure secrets manager):
```
PORT=5000
CORS_ORIGIN=https://yourdomain.com
JWT_SECRET=change_this_to_a_strong_secret
DATABASE_URL=postgresql://bb_user:bb_pass@db:5432/bb_db?schema=public
ADMIN_EMAILS=admin@yourdomain.com
```
2. Build & start:
```bash
cd docker
docker compose -f docker-compose.prod.yml up --build -d
```
3. If you use the `nginx` service make sure `docker/nginx.conf` is configured to serve `/` and proxy `/api` to the backend (example `docker/nginx.conf` exists in the repo). The `frontend` image is expected to produce static files served into the `frontend_static` volume — you might prefer to change the frontend Dockerfile to copy built files into that volume location or adapt nginx to proxy directly to the frontend container port.

### Notes / Recommendations
- Use `.env` with strong secrets and keep it out of source control.
- For TLS in production, consider provisioning certificates with Certbot on the host or using a managed load balancer (recommended).
- For scaling or production orchestration, consider Kubernetes or Docker Swarm rather than a single `docker-compose`.
