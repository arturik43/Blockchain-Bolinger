# Blockchain-Bolinger — Komplettes Projekt-Paket

**DroidCoach Report** — Master, hier ist das vollständige Projekt-Paket: Quellcode, Konfigurationen, Docker-Compose, CI/CD Workflows und Deploy-/Ops-Skripte. Dieses ZIP enthält alles, damit du das Projekt lokal laufen, in Docker deployen oder in CI/CD integrieren kannst.

> Generiert: 2025-09-13T22:06:05.410212Z

---

## Inhalt (Kurzübersicht)
- `frontend/` — React + Vite + Tailwind UI (Quelle, Komponenten, API-Clients)
- `backend/` — Node.js + Express, Prisma ORM, Auth (JWT+Refresh), Trades, Portfolio, Import/Export, Audit, Admin routes
- `docker/` — Dockerfiles, `docker-compose.yml`, `docker-compose.prod.yml`, `nginx.conf`
- `scripts/` — `deploy.sh`, `setup_env.sh`
- `.github/workflows/` — `ci.yml`, `deploy.yml` (GitHub Actions)
- `docs/` — `DEPLOYMENT.md`, `TRADES.md` (Import/Export docs)
- `prisma/` — schema.prisma (DB models), migrations (if present)
- README (dieses Dokument) + weitere Hilfsdateien

---

## Quickstart (lokal, Development)
1. Klone das Repo (oder entpacke das ZIP)
```bash
unzip blockchain-bolinger-project_complete_package.zip -d blockchain-bolinger-project
cd blockchain-bolinger-project/backend
```

2. Environment templates erzeugen (Optional)
```bash
./scripts/setup_env.sh
# Edit backend/.env und frontend/.env.local nach Bedarf
```

3. Starte lokale Postgres (Docker) oder verwende eine existierende DB:
```bash
docker run -d --name bb_db -e POSTGRES_USER=bb_user -e POSTGRES_PASSWORD=bb_pass -e POSTGRES_DB=bb_db -p 5432:5432 postgres:15
```

4. Backend einrichten & starten
```bash
cd backend
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```
5. Frontend starten
```bash
cd ../frontend
npm install
npm run dev
# Dann: http://localhost:3000
```

---

## Haupt-Funktionen (Implementiert)
- **Auth**: Register/Login, JWT Access (15m), Refresh Token (httpOnly cookie), Auto-Admin für ersten Benutzer
- **Trades**: CRUD + AVG & FIFO Kostenbasis, realized PnL, 90d PnL-History
- **CSV Import/Export**: Preview, inline-edit, commit (JSON), batch import rollback, error reports, download errors CSV
- **Portfolio**: Holdings, valuation via external price service (Coingecko), Pie-chart components
- **Audit-Log**: Server-side audit entries for key actions; user audit view + admin audit (global)
- **Admin**: Admin API for listing users, promoting users, exporting audit logs
- **Caching**: Simple in-memory TTL cache for external API calls
- **Docker & Prod Deploy**: `docker/docker-compose.prod.yml`, nginx reverse proxy, TLS instructions
- **CI/CD**: GitHub Actions workflows for CI and image build/deploy to Docker Hub or SSH deploy

---

## Deployment (Production)
1. Editiere `backend/.env` mit Production-Werten (DATABASE_URL, JWT_SECRET, ADMIN_EMAILS, CORS_ORIGIN)
2. Setze Domain A-Record und öffne Ports 80/443
3. Optional: TLS via Let's Encrypt (siehe `docs/DEPLOYMENT.md`)
4. Starte Prod-Compose:
```bash
cd docker
docker compose -f docker-compose.prod.yml up --build -d
```

---

## GitHub Actions (CI/CD)
- `ci.yml` führt in PRs/builds: Prisma generate, migrate deploy (wenn migrations vorhanden), Backend tests (falls), Frontend build.
- `deploy.yml` baut Docker-Images und pusht zu Docker Hub; optionaler SSH-Deploy (benötigt GitHub Secrets).

**Wichtige Secrets**:
- `DOCKERHUB_USERNAME`, `DOCKERHUB_TOKEN`, `DOCKERHUB_REPO`
- Optional: `REMOTE_HOST`, `REMOTE_USER`, `SSH_PRIVATE_KEY`, `REMOTE_DIR`

---

## Wichtige Pfade & Dateien (Kurzreferenz)
- Backend routes: `backend/src/routes/auth.js`, `trades.js`, `audit.js`, `adminAudit.js`
- Backend utils: `backend/src/utils/audit.js`, `cache.js`, `prisma.js`
- Prisma schema: `backend/prisma/schema.prisma`
- Frontend main: `frontend/src/App.tsx`, `components/features/TradesTab.tsx`, `AdminAuditTab.tsx`
- Docker compose (prod): `docker/docker-compose.prod.yml`
- Nginx config: `docker/nginx.conf`
- Scripts: `scripts/deploy.sh`, `scripts/setup_env.sh`
- Docs: `docs/DEPLOYMENT.md`, `docs/TRADES.md`

---

## Sicherheit & Betrieb (Kurz)
- Setze `JWT_SECRET` stark & geheim. Verwende HTTPS in Prod (Let's Encrypt).
- Cookie `bb_refresh` ist httpOnly; in Prod `secure: true` setzen (HTTPS required).
- Migrations: committe `prisma/migrations` bevor Migration in CI & Prod.
- R8/ProGuard (für mobile) und source maps handling (for release) sind außerhalb dieses package scope.

---

## Troubleshooting (häufige Probleme)
- **Prisma DB errors**: Prüfe `DATABASE_URL`, starte Postgres, führe `npx prisma migrate dev` aus.
- **401 auf API**: Prüfe Cookies (`bb_refresh`) und CORS (Backend `.env` `CORS_ORIGIN`).
- **Nginx 502**: Prüfe, ob backend container unter `backend:5000` reachable ist.
- **Let's Encrypt failures**: Stelle sicher Domain gezeigt wird und Port 80 nicht blockiert.

---

## Nächste Schritte & Empfehlungen
- E2E Tests (Playwright) in CI. Ich kann die Tests für kritische flows anlegen.
- Redis für API Caching & job queue (skalierbar).
- Monitoring (Sentry/Prometheus) & performance tests.

---

## Support
Wenn du möchtest, Master, kann ich:
- ein Release-Tag + GitHub Release vorbereiten,
- die GitHub Actions mit secrets konfigurieren (Anleitung),
- oder das System auf deinen Server deployen (wenn du mir die Details gibst).

Sag einfach: `DeployNow` oder `SetupCISecrets` oder `AddE2E` — ich mache es sofort.

---
*Ende der README*
