
#!/usr/bin/env bash
set -euo pipefail
# scripts/setup_env.sh - create .env templates for backend and frontend
cat > backend/.env <<'EOF'
PORT=5000
CORS_ORIGIN=http://localhost:3000
JWT_SECRET=change_this_secret
DATABASE_URL=postgresql://bb_user:bb_pass@localhost:5432/bb_db?schema=public
ADMIN_EMAILS=   # optional, comma separated
EOF

cat > frontend/.env.local <<'EOF'
VITE_API_URL=http://localhost:5000/api
VITE_WEBSOCKET_URL=ws://localhost:5000
VITE_ENABLE_AI_FEATURES=true
EOF

echo "Created backend/.env and frontend/.env.local (templates). Edit them before running."
