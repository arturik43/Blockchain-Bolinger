
#!/usr/bin/env bash
set -euo pipefail
# scripts/deploy.sh
# Usage:
#  ./scripts/deploy.sh local          -> run docker compose up --build -d (local)
#  ./scripts/deploy.sh dockerhub      -> build images and push to Docker Hub (requires DOCKERHUB_USER & DOCKERHUB_TOKEN)
#  ./scripts/deploy.sh ssh            -> build images, scp docker-compose.yml to remote and ssh run docker compose pull && docker compose up -d
COMPOSE_FILE=${COMPOSE_FILE:-docker/docker-compose.yml}
cmd=${1:-local}

function ensure_docker_compose {
  if [ ! -f "$COMPOSE_FILE" ]; then
    echo "Compose file not found: $COMPOSE_FILE"
    exit 1
  fi
}

function local_up {
  ensure_docker_compose
  echo "Starting local docker compose..."
  docker compose -f "$COMPOSE_FILE" pull || true
  docker compose -f "$COMPOSE_FILE" up --build -d
  echo "Local services started."
}

function dockerhub_push {
  ensure_docker_compose
  if [ -z "${DOCKERHUB_USER:-}" ] || [ -z "${DOCKERHUB_TOKEN:-}" ]; then
    echo "DOCKERHUB_USER and DOCKERHUB_TOKEN must be set."
    exit 1
  fi
  echo "$DOCKERHUB_TOKEN" | docker login -u "$DOCKERHUB_USER" --password-stdin
  TAG=${TAG:-latest}
  FRONTEND_IMAGE=${DOCKERHUB_USER}/${DOCKERHUB_REPO:-blockchain-bolinger}-frontend:$TAG
  BACKEND_IMAGE=${DOCKERHUB_USER}/${DOCKERHUB_REPO:-blockchain-bolinger}-backend:$TAG
  echo "Building backend image: $BACKEND_IMAGE"
  docker build -t "$BACKEND_IMAGE" -f docker/Dockerfile.backend backend
  echo "Building frontend image: $FRONTEND_IMAGE"
  docker build -t "$FRONTEND_IMAGE" -f docker/Dockerfile.frontend frontend
  docker push "$BACKEND_IMAGE"
  docker push "$FRONTEND_IMAGE"
  echo "Images pushed to Docker Hub."
}

function ssh_deploy {
  ensure_docker_compose
  if [ -z "${REMOTE_HOST:-}" ]; then echo "REMOTE_HOST must be set"; exit 1; fi
  REMOTE_USER=${REMOTE_USER:-root}
  REMOTE_DIR=${REMOTE_DIR:-/opt/blockchain-bolinger}
  SSH_PORT=${SSH_PORT:-22}
  echo "Copying compose file to remote and running docker compose..."
  scp -P "$SSH_PORT" "$COMPOSE_FILE" "${REMOTE_USER}@${REMOTE_HOST}:$REMOTE_DIR/docker-compose.yml"
  ssh -p "$SSH_PORT" "${REMOTE_USER}@${REMOTE_HOST}" "cd $REMOTE_DIR && docker compose pull && docker compose up -d --remove-orphans"
  echo "Remote deploy triggered."
}

case "$cmd" in
  local) local_up ;;
  dockerhub) dockerhub_push ;;
  ssh) ssh_deploy ;;
  *) echo "Unknown command: $cmd"; exit 1 ;;
esac
