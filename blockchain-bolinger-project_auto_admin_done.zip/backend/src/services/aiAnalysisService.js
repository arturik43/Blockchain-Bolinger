import axios from 'axios'
export async function buildInsights(){
  try {
    const { data } = await axios.get('https://api.coingecko.com/api/v3/coins/markets', {
      params: { vs_currency: 'eur', order: 'market_cap_desc', per_page: 5, page: 1, sparkline: false }
    })
    const avg = data.reduce((a,c)=>a+(c.price_change_percentage_24h||0),0)/data.length
    const sentiment = avg > 1 ? 'bullish' : avg < -1 ? 'bearish' : 'neutral'
    return {
      sentiment,
      score: Math.max(0, Math.min(100, Math.round((avg+5)*10))),
      highlights: data.map(c => ({ text: `${c.name} ${c.price_change_percentage_24h?.toFixed(2)}%`, weight: Math.abs(c.price_change_percentage_24h||0)/10 }))
    }
  } catch {
    return { sentiment: 'neutral', score: 50, highlights: [{ text: 'Fallback data', weight: 0.1 }] }
  }
}
