import { Router } from 'express'
import axios from 'axios'
import { requireAuth } from '../middleware/auth.js'
import { prisma } from '../utils/prisma.js'

const r = Router()

r.get('/', requireAuth, async (req, res) => {
  const items = await prisma.holding.findMany({ where: { userId: req.user.id } })
  res.json(items)
})

r.post('/', requireAuth, async (req, res) => {
  const { coinId, symbol, amount, entryPrice } = req.body || {}
  if(!coinId || !symbol || typeof amount !== 'number') return res.status(400).json({ error: 'invalid_body' })
  const data = { amount, symbol, entryPrice: typeof entryPrice==='number' ? entryPrice : 0 }
  const holding = await prisma.holding.upsert({
    where: { userId_coinId: { userId: req.user.id, coinId } },
    update: data,
    create: { ...data, coinId, userId: req.user.id }
  })
  res.json(holding)
})

r.delete('/:coinId', requireAuth, async (req, res) => {
  await prisma.holding.delete({ where: { userId_coinId: { userId: req.user.id, coinId: req.params.coinId } } }).catch(()=>null)
  res.json({ ok: true })
})

// Valuation with PnL
r.get('/valuation', requireAuth, async (req, res) => {
  const items = await prisma.holding.findMany({ where: { userId: req.user.id } })
  if(items.length === 0) return res.json({ total: 0, positions: [] })
  const ids = items.map(i=>i.coinId).join(',')
  try {
    const { data } = await axios.get('https://api.coingecko.com/api/v3/coins/markets', {
      params: { vs_currency: 'eur', ids, order: 'market_cap_desc', per_page: 250, page: 1, sparkline: false }
    })
    const byId = Object.fromEntries(data.map(c=>[c.id, c]))
    const positions = items.map(h => {
      const m = byId[h.coinId]
      const price = m?.current_price || 0
      const value = price * h.amount
      const cost = (h.entryPrice || 0) * h.amount
      const pnl = value - cost
      const pnlPct = cost > 0 ? (pnl / cost) * 100 : null
      return { ...h, price, value, cost, pnl, pnlPct }
    })
    const total = positions.reduce((s,p)=>s+p.value,0)
    res.json({ total, positions })
  } catch (e) {
    res.status(500).json({ error: 'valuation_failed', detail: e?.message })
  }
})

export default r
