import { Router } from 'express'
import { requireAuth } from '../middleware/auth.js'
import { prisma } from '../utils/prisma.js'

const r = Router()

// GET /api/audit?limit=100
r.get('/', requireAuth, async (req, res) => {
  const limit = Math.min(1000, Number(req.query.limit) || 100)
  const logs = await prisma.auditLog.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: 'desc' },
    take: limit
  })
  res.json(logs)
})

export default r
