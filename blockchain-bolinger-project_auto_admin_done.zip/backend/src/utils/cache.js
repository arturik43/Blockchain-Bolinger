const store = new Map()

export function setCache(key, data, ttlMs = 60_000){
  const expires = Date.now() + ttlMs
  store.set(key, { data, expires })
}

export function getCache(key){
  const it = store.get(key)
  if(!it) return null
  if(Date.now() > it.expires){ store.delete(key); return null }
  return it.data
}
