import { fetchWithAuth } from './AuthAPI'
export async function listAudit(limit=200){ return await fetchWithAuth(`/audit?limit=${limit}`) }
