import React, { useEffect, useMemo, useState } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { getTopCoins } from '../../services/api/CryptoAPI'
import { getPortfolio, upsertHolding, removeHolding, Holding } from '../../services/api/PortfolioAPI'
import { Trash2, Plus } from 'lucide-react'
import AllocationPie from '../portfolio/PieChart'

type Coin = { id:string; symbol:string; name:string; image:string; current_price:number }

export default function PortfolioTab(){
  const { user } = useAuth()
  const [coins, setCoins] = useState<Coin[]>([])
  const [holdings, setHoldings] = useState<(Holding & { entryPrice?: number })[]>([])
  const [form, setForm] = useState({ coinId:'', symbol:'', amount:'', entryPrice:'' })

  useEffect(() => { getTopCoins().then(setCoins) }, [])
  useEffect(() => {
    if(user){
      getPortfolio().then(setHoldings).catch(()=>setHoldings([]))
    } else {
      const local = localStorage.getItem('bb_portfolio')
      setHoldings(local ? JSON.parse(local) : [])
    }
  }, [user])

  const { total, alloc, rows } = useMemo(() => {
    const byId = Object.fromEntries(coins.map(c=>[c.id,c]))
    let t = 0
    const r = holdings.map(h=>{
      const c = byId[h.coinId]; const price = c?.current_price||0
      const value = price * h.amount
      const cost = (h.entryPrice||0) * h.amount
      const pnl = value - cost
      const pnlPct = cost>0 ? (pnl/cost)*100 : null
      t += value
      return { ...h, price, value, cost, pnl, pnlPct, name: c?.name||h.symbol }
    })
    const alloc = r.filter(x=>x.value>0).map(x=>({ name: x.name, value: Number(x.value.toFixed(2)) }))
    return { total: t, alloc, rows: r }
  }, [coins, holdings])

  async function addOrUpdate(){
    const amt = parseFloat(form.amount||'0')
    const ep = parseFloat(form.entryPrice||'0')
    if(!form.coinId || !amt) return
    const next = { coinId: form.coinId, symbol: form.symbol, amount: amt, entryPrice: isFinite(ep)? ep : 0 }
    if(user){
      await upsertHolding(next); setHoldings(await getPortfolio())
    } else {
      const list = [...holdings]
      const idx = list.findIndex(x=>x.coinId===next.coinId)
      if(idx>=0) list[idx]={...list[idx], ...next}; else list.push(next as any)
      setHoldings(list); localStorage.setItem('bb_portfolio', JSON.stringify(list))
    }
    setForm({ coinId:'', symbol:'', amount:'', entryPrice:'' })
  }

  async function del(id:string){
    if(user){ await removeHolding(id); setHoldings(await getPortfolio()) }
    else {
      const list = holdings.filter(h=>h.coinId!==id)
      setHoldings(list); localStorage.setItem('bb_portfolio', JSON.stringify(list))
    }
  }

  return (
    <div className="px-4 py-4 pb-24">
      <h1 className="text-white text-2xl font-bold mb-6">Portfolio</h1>

      <div className="card p-4 mb-6">
        <div className="grid md:grid-cols-5 gap-3">
          <select className="bg-slate-800 text-white rounded-xl p-3"
            value={form.coinId}
            onChange={e=>{
              const coin = coins.find(c=>c.id===e.target.value)
              setForm({ ...form, coinId: e.target.value, symbol: (coin?.symbol||'').toUpperCase() })
            }}>
            <option value="">Coin wählen…</option>
            {coins.map(c=>(<option key={c.id} value={c.id}>{c.name} ({c.symbol.toUpperCase()})</option>))}
          </select>
          <input className="bg-slate-800 text-white rounded-xl p-3" placeholder="Symbol" value={form.symbol} onChange={e=>setForm({ ...form, symbol:e.target.value })}/>
          <input className="bg-slate-800 text-white rounded-xl p-3" placeholder="Menge" value={form.amount} onChange={e=>setForm({ ...form, amount:e.target.value })}/>
          <input className="bg-slate-800 text-white rounded-xl p-3" placeholder="Einstandspreis (EUR)" value={form.entryPrice} onChange={e=>setForm({ ...form, entryPrice:e.target.value })}/>
          <button className="btn" onClick={addOrUpdate}><Plus size={16}/> Hinzufügen/Updaten</button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-6">
        <div className="card p-4">
          <div className="flex justify-between mb-3">
            <div className="text-slate-300">Bestände</div>
            <div className="text-slate-100 font-semibold">Gesamtwert: € {total.toLocaleString('de-DE')}</div>
          </div>
          <ul className="divide-y divide-slate-800">
            {rows.map(h=> (
              <li key={h.coinId} className="py-3 flex items-center gap-3">
                <div className="flex-1">
                  <div className="font-medium">{h.name} <span className="text-slate-400">({h.symbol})</span></div>
                  <div className="text-sm text-slate-400">Menge: {h.amount} | Preis: € {h.price.toLocaleString('de-DE')}</div>
                  <div className={"text-sm " + (h.pnl>=0 ? "text-emerald-400":"text-rose-400")}>
                    Wert: € {h.value.toLocaleString('de-DE')} • Cost: € {h.cost.toLocaleString('de-DE')} • PnL: € {h.pnl.toLocaleString('de-DE')} {h.pnlPct!==null ? `(${h.pnlPct.toFixed(2)}%)` : ""}
                  </div>
                </div>
                <button className="text-rose-400 hover:text-rose-300" onClick={()=>del(h.coinId)}><Trash2/></button>
              </li>
            ))}
          </ul>
        </div>
        <div className="card p-4">
          <div className="text-slate-300 mb-2">Allocation</div>
          <AllocationPie data={alloc} />
        </div>
      </div>
    </div>
  )
}
