import React, { useEffect, useState } from 'react'
import { adminListAudit, adminExportAudit, adminListUsers, adminPromote } from '../../services/api/AdminAPI'
import { useAuth } from '../../contexts/AuthContext'

export default function AdminAuditTab(){
  const { user } = useAuth()
  const [logs, setLogs] = useState<any[]>([])
  const [users, setUsers] = useState<any[]>([])
  const [limit, setLimit] = useState(200)
  const [filterUser, setFilterUser] = useState('')

  useEffect(()=>{ if(user) load() }, [user])

  async function load(){
    try{
      const l = await adminListAudit(limit, filterUser)
      setLogs(l || [])
      const u = await adminListUsers(200)
      setUsers(u || [])
    } catch(e){ console.warn('admin load failed', e) }
  }

  async function exportCsv(){
    try{
      const b = await adminExportAudit(limit, filterUser)
      const url = URL.createObjectURL(b); const a = document.createElement('a'); a.href = url; a.download = 'audit_export.csv'; a.click()
    } catch(e){ console.warn(e) }
  }

  async function promote(uId:string){ await adminPromote(uId); await load() }

  if(!user) return <div className="card p-4 text-amber-300">Bitte einloggen.</div>

  return (
    <div className="px-4 py-4 pb-24">
      <h1 className="text-white text-2xl font-bold mb-6">Admin — Audit</h1>
      <div className="card p-4 mb-6">
        <div className="flex gap-3 items-center mb-3">
          <input className="bg-slate-800 text-white p-2 rounded" placeholder="Filter userId" value={filterUser} onChange={e=>setFilterUser(e.target.value)} />
          <input type="number" className="bg-slate-800 text-white p-2 rounded w-28" value={limit} onChange={e=>setLimit(Number(e.target.value))} />
          <button className="btn" onClick={load}>Load</button>
          <button className="btn" onClick={exportCsv}>Export CSV</button>
        </div>
        <div className="text-slate-300 mb-2">Users</div>
        <ul className="divide-y divide-slate-800 mb-3">
          {users.map(u=>(
            <li key={u.id} className="py-2 flex justify-between items-center">
              <div><div className="font-medium">{u.email}</div><div className="text-sm text-slate-400">role: {u.role}</div></div>
              <div>
                {u.role !== 'admin' && <button className="btn" onClick={()=>promote(u.id)}>Promote</button>}
              </div>
            </li>
          ))}
        </ul>
      </div>

      <div className="card p-4">
        <div className="text-slate-300 mb-3">Audit Logs (latest {limit})</div>
        <ul className="divide-y divide-slate-800">
          {logs.map(l=>(
            <li key={l.id} className="py-3">
              <div className="text-sm text-slate-400">{new Date(l.createdAt).toLocaleString('de-DE')} — {l.ip || '-'}</div>
              <div className="font-medium">{l.action} <span className="text-slate-400">user:{l.userId||'-'}</span></div>
              <pre className="text-xs mt-2 p-2 bg-slate-900 rounded">{JSON.stringify(l.details||{}, null, 2)}</pre>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
