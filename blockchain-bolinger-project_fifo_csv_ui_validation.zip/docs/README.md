# Blockchain-Bolinger – Schnellstart + Auth/Portfolio/AI

## Lokal
```bash
cd backend && npm install && npm run dev
# neues Terminal
cd frontend && npm install && npm run dev
```
- Frontend: http://localhost:3000  
- Backend:  http://localhost:5000/api/health

## Docker
```bash
cd docker
docker compose up --build
```

## Neue Endpoints
- POST `/api/auth/register` `{ email, password }` → `{ token, user }`
- POST `/api/auth/login` `{ email, password }` → `{ token, user }`
- GET `/api/portfolio` (Bearer) → Holdings
- POST `/api/portfolio` (Bearer) `{ coinId, symbol, amount }`
- DELETE `/api/portfolio/:coinId` (Bearer)
- GET `/api/ai/insights` → Heuristische Marktanalyse

## ENV
**backend/.env**
```
PORT=5000
CORS_ORIGIN=http://localhost:3000
JWT_SECRET=dev_change_me
NEWS_API_KEY=
COINGECKO_API_KEY=
```

**frontend/.env.local**
```
VITE_API_URL=http://localhost:5000/api
VITE_WEBSOCKET_URL=ws://localhost:5000
VITE_ENABLE_AI_FEATURES=true
```

## Hinweise
- Passwörter werden mit `bcryptjs` gehasht, Auth via JWT.
- Portfolio wird in JSON-Datei gespeichert (leicht ersetzbar durch DB).
- Tailwind `darkMode: 'class'`, Farben/Reset gemäß gelieferten Snippets.
