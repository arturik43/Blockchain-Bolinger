# Trades, Cost-Basis & PnL

## Endpoints
- **GET** `/api/trades` – Liste der Trades (usergebunden)
- **POST** `/api/trades` – { coinId, symbol, side: BUY|SELL, quantity, price, fee?, ts? }
- **DELETE** `/api/trades/:id`
- **GET** `/api/trades/positions/avg` – Durchschnittlicher Einstand je Coin (AVG-Methode)
- **GET** `/api/trades/pnl/history` – Tägliche PnL-Kurve (90 Tage) basierend auf AVG und Marktpreisen

## Hinweise
- **AVG** statt FIFO für einfache PnL-Berechnung (FIFO kann leicht ergänzt werden).
- Preise via **CoinGecko market_chart** (EUR) – 90 Tage, in-memory Cache (5 Min.).


## CSV Import / Export
- **Import**: `POST /api/trades/import` (multipart/form-data, file field `file`), CSV headers: `side,coinId,symbol,quantity,price,fee,ts`
- **Export**: `GET /api/trades/export` returns `trades_export.csv`

## Cost Methods
- `AVG` (existing) and `FIFO` (new) supported.
- Use `GET /api/trades/positions?method=fifo` for FIFO positions (includes realized PnL per coin).


## CSV Validation
- Import validates each row; returns `errors` array with `{ row, errors }` objects describing issues per CSV row.
- Required columns: `side,coinId,quantity,price` (symbol optional, fee optional, ts optional).
