import React, { createContext, useContext, useEffect, useState } from 'react'

type User = { id: string; email: string } | null
type AuthCtx = {
  user: User
  token: string | null
  login: (email:string, password:string) => Promise<boolean>
  register: (email:string, password:string) => Promise<boolean>
  logout: () => void
}

const Ctx = createContext<AuthCtx>({
  user: null, token: null,
  async login(){ return false }, async register(){ return false }, logout(){}
})

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

export const AuthProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const [user, setUser] = useState<User>(null)
  const [token, setToken] = useState<string | null>(null)

  useEffect(() => {
    const t = localStorage.getItem('bb_token')
    const u = localStorage.getItem('bb_user')
    if(t && u){ setToken(t); setUser(JSON.parse(u)) }
  }, [])

  async function login(email:string, password:string){
    try {
      const r = await fetch(`${API}/auth/login`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password }) })
      if(!r.ok) return false
      const data = await r.json()
      setToken(data.token); setUser(data.user)
      localStorage.setItem('bb_token', data.token)
      localStorage.setItem('bb_user', JSON.stringify(data.user))
      return true
    } catch { return false }
  }

  async function register(email:string, password:string){
    try {
      const r = await fetch(`${API}/auth/register`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password }) })
      if(!r.ok) return false
      const data = await r.json()
      setToken(data.token); setUser(data.user)
      localStorage.setItem('bb_token', data.token)
      localStorage.setItem('bb_user', JSON.stringify(data.user))
      return true
    } catch { return false }
  }

  function logout(){
    setToken(null); setUser(null)
    localStorage.removeItem('bb_token'); localStorage.removeItem('bb_user')
  }

  return <Ctx.Provider value={{ user, token, login, register, logout }}>{children}</Ctx.Provider>
}

export function useAuth(){ return useContext(Ctx) }
