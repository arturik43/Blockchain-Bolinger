import { fetchWithAuth } from './AuthAPI'
export type Holding = { coinId: string; symbol: string; amount: number }
export async function getPortfolio(){ return await fetchWithAuth('/portfolio') }
export async function upsertHolding(h: Holding){ return await fetchWithAuth('/portfolio', 'POST', h) }
export async function removeHolding(coinId: string){ return await fetchWithAuth(`/portfolio/${coinId}`, 'DELETE') }
