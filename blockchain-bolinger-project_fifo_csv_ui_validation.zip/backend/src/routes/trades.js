import { Router } from 'express'
import { prisma } from '../utils/prisma.js'
import { requireAuth } from '../middleware/auth.js'
import { getMarketChartEUR } from '../services/prices.js'
import multer from 'multer'

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024 } })

const r = Router()

// List
r.get('/', requireAuth, async (req, res) => {
  const trades = await prisma.trade.findMany({ where: { userId: req.user.id }, orderBy: { ts: 'desc' } })
  res.json(trades)
})

// Create
r.post('/', requireAuth, async (req, res) => {
  const { coinId, symbol, side, quantity, price, fee, ts } = req.body || {}
  if(!coinId || !symbol || !side || !quantity || !price) return res.status(400).json({ error: 'invalid_body' })
  const trade = await prisma.trade.create({ data: { userId: req.user.id, coinId, symbol, side, quantity: Number(quantity), price: Number(price), fee: Number(fee||0), ts: ts ? new Date(ts) : new Date() } })
  res.json(trade)
})

// Delete
r.delete('/:id', requireAuth, async (req, res) => {
  await prisma.trade.delete({ where: { id: req.params.id } }).catch(()=>null)
  res.json({ ok: true })
})

// AVG positions (legacy endpoint)
r.get('/positions/avg', requireAuth, async (req, res) => {
  const trades = await prisma.trade.findMany({ where: { userId: req.user.id }, orderBy: { ts: 'asc' } })
  const map = new Map()
  for(const t of trades){
    const key = t.coinId
    const pos = map.get(key) || { amount: 0, cost: 0 }
    if(t.side === 'BUY'){
      pos.cost += t.price * t.quantity + (t.fee||0)
      pos.amount += t.quantity
    } else {
      const avg = pos.amount>0 ? pos.cost/pos.amount : 0
      pos.amount -= t.quantity
      pos.cost -= avg * t.quantity
      if(pos.amount < 1e-8){ pos.amount = 0; pos.cost = 0 }
    }
    map.set(key, pos)
  }
  const result = [...map.entries()].map(([coinId, pos]) => ({
    coinId, amount: Number(pos.amount.toFixed(8)), entryPrice: pos.amount>0 ? Number((pos.cost/pos.amount).toFixed(8)) : 0
  }))
  res.json(result)
})

// FIFO positions & realized PnL
r.get('/positions', requireAuth, async (req, res) => {
  const method = (req.query.method || 'fifo').toLowerCase()
  if(method === 'avg') return res.redirect(303, '/api/trades/positions/avg')
  // fifo
  const trades = await prisma.trade.findMany({ where: { userId: req.user.id }, orderBy: { ts: 'asc' } })
  const lotsMap = new Map() // coinId -> [{qty, price, fee}]
  const realized = new Map()
  for(const t of trades){
    const coin = t.coinId
    if(!lotsMap.has(coin)) lotsMap.set(coin, [])
    if(!realized.has(coin)) realized.set(coin, 0)
    const lots = lotsMap.get(coin)
    if(t.side === 'BUY'){
      lots.push({ qty: t.quantity, price: t.price, fee: t.fee||0 })
    } else {
      let remaining = t.quantity
      let realize = 0
      while(remaining > 0 && lots.length > 0){
        const lot = lots[0]
        const take = Math.min(lot.qty, remaining)
        const costRemoved = take * lot.price
        const proceeds = take * t.price
        // allocate proportional fee: include seller fee into realized cost reduction
        const feeShare = (take / lot.qty) * (lot.fee||0) // approximate fee share from buy lot
        realize += proceeds - costRemoved - (t.fee||0) * (take / t.quantity) - feeShare
        lot.qty -= take
        remaining -= take
        if(lot.qty <= 1e-12) lots.shift()
      }
      // if we sold more than we had, we treat remaining as negative position (allow negative lots)
      if(remaining > 0){
        // create negative lot representing short (rare)
        lots.unshift({ qty: -remaining, price: t.price, fee: 0 })
      }
      realized.set(coin, (realized.get(coin) || 0) + realize)
    }
  }

  // build positions
  const positions = []
  for(const [coin, lots] of lotsMap.entries()){
    const amount = lots.reduce((s,l)=>s + (l.qty||0), 0)
    const cost = lots.reduce((s,l)=>s + (l.qty>0 ? l.qty*l.price + (l.fee||0) : 0), 0)
    const entryPrice = amount>0 ? cost / amount : 0
    positions.push({ coinId: coin, amount, entryPrice, realizedPnl: Number((realized.get(coin)||0).toFixed(8)) })
  }
  res.json(positions)
})

// Historical PnL curve (90d) using AVG method kept as-is (can be extended to FIFO if needed)
r.get('/pnl/history', requireAuth, async (req, res) => {
  const trades = await prisma.trade.findMany({ where: { userId: req.user.id }, orderBy: { ts: 'asc' } })
  const coins = [...new Set(trades.map(t=>t.coinId))]
  const charts = {}
  for(const c of coins){
    charts[c] = await getMarketChartEUR(c, 90)
  }
  const days = new Set()
  for(const c of coins){
    (charts[c].prices||[]).forEach(p=>days.add(new Date(new Date(p[0]).toDateString()).getTime()))
  }
  const timeline = [...days].sort((a,b)=>a-b)
  const state = {}
  const byDay = timeline.map(dayTs => {
    for(const t of trades){
      const tDay = new Date(new Date(t.ts).toDateString()).getTime()
      if(tDay === dayTs){
        const pos = state[t.coinId] || { amount:0, cost:0 }
        if(t.side === 'BUY'){
          pos.cost += t.price * t.quantity + (t.fee||0)
          pos.amount += t.quantity
        } else {
          const avg = pos.amount>0 ? pos.cost/pos.amount : 0
          pos.amount -= t.quantity
          pos.cost -= avg * t.quantity
          if(pos.amount < 1e-8){ pos.amount = 0; pos.cost = 0 }
        }
        state[t.coinId] = pos
      }
    }
    let equity = 0, cost = 0
    for(const c of coins){
      const price = nearestPrice(charts[c].prices, dayTs)
      const pos = state[c] || { amount:0, cost:0 }
      equity += (price||0) * pos.amount
      cost += pos.cost
    }
    return { t: dayTs, equity, cost, pnl: equity - cost }
  })
  res.json(byDay)
})

function nearestPrice(prices, dayTs){
  if(!prices || prices.length===0) return 0
  let best = prices[0][1], bestDiff = Math.abs(prices[0][0]-dayTs)
  for(const [ts, p] of prices){
    const d = Math.abs(ts - dayTs)
    if(d < bestDiff){ best = p; bestDiff = d }
  }
  return best
}

// CSV Import (expects headers: side,coinId,symbol,quantity,price,fee,ts)
r.post('/import', requireAuth, upload.single('file'), async (req, res) => {r.post('/import', requireAuth, upload.single('file'), async (req, res) => {
  if(!req.file) return res.status(400).json({ error: 'missing_file' })
  const txt = req.file.buffer.toString('utf-8')
  const lines = txt.split(/\r?\n/).map(l=>l.trim()).filter(Boolean)
  if(lines.length === 0) return res.status(400).json({ error: 'empty_file' })
  const header = lines.shift().split(',').map(h=>h.trim().toLowerCase())
  const required = ['side','coinid','symbol','quantity','price']
  const missingCols = required.filter(c => !header.includes(c))
  if(missingCols.length) return res.status(400).json({ error: 'missing_columns', details: missingCols })

  const created = []
  const errors = []
  for(const [i, ln] of lines.entries()){
    const cols = ln.split(',').map(c=>c.trim())
    const obj = {}
    header.forEach((h,idx)=>obj[h]=cols[idx])
    const rowNum = i+2 // including header
    // validate fields
    const rowErrors = []
    if(!obj.side || !['BUY','SELL'].includes(obj.side.toUpperCase())) rowErrors.push('side must be BUY or SELL')
    if(!obj.coinid) rowErrors.push('coinId missing')
    if(!obj.quantity || isNaN(Number(obj.quantity))) rowErrors.push('quantity invalid')
    if(!obj.price || isNaN(Number(obj.price))) rowErrors.push('price invalid')
    if(rowErrors.length){ errors.push({ row: rowNum, errors: rowErrors }); continue }
    try{
      const t = await prisma.trade.create({ data: {
        userId: req.user.id,
        coinId: obj.coinid,
        symbol: obj.symbol || '',
        side: obj.side.toUpperCase(),
        quantity: Number(obj.quantity),
        price: Number(obj.price),
        fee: Number(obj.fee||0),
        ts: obj.ts ? new Date(obj.ts) : new Date()
      }})
      created.push(t)
    } catch(e){
      errors.push({ row: rowNum, errors: ['db_error', e?.message || 'unknown'] })
    }
  }
  res.json({ created: created.length, errors })
})
})

// CSV Export
r.get('/export', requireAuth, async (req, res) => {
  const trades = await prisma.trade.findMany({ where: { userId: req.user.id }, orderBy: { ts: 'asc' } })
  const header = ['id','side','coinId','symbol','quantity','price','fee','ts']
  const rows = trades.map(t=>[t.id,t.side,t.coinId,t.symbol,t.quantity,t.price,t.fee,t.ts.toISOString()])
  const csv = [header.join(','), ...rows.map(r=>r.join(','))].join('\n')
  res.setHeader('Content-Type', 'text/csv')
  res.setHeader('Content-Disposition', 'attachment; filename="trades_export.csv"')
  res.send(csv)
})

export default r
