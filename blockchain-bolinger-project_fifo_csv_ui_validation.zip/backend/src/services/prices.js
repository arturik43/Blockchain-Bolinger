import axios from 'axios'
import { getCache, setCache } from '../utils/cache.js'

export async function getTopCoinsEUR(limit=10){
  const key = `topcoins_${limit}`
  const hit = getCache(key)
  if(hit) return hit
  const { data } = await axios.get('https://api.coingecko.com/api/v3/coins/markets', {
    params: { vs_currency: 'eur', order: 'market_cap_desc', per_page: limit, page: 1, sparkline: false }
  })
  setCache(key, data, 60_000)
  return data
}

export async function getMarketChartEUR(coinId, days=90){
  const key = `chart_${coinId}_${days}`
  const hit = getCache(key)
  if(hit) return hit
  const { data } = await axios.get(`https://api.coingecko.com/api/v3/coins/${coinId}/market_chart`, {
    params: { vs_currency: 'eur', days }
  })
  setCache(key, data, 5 * 60_000)
  return data
}
