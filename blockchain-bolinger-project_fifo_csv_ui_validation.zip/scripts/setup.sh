#!/usr/bin/env bash
set -e
cd backend && npm install && cd ..
cd frontend && npm install && cd ..
echo "Ready. Start backend: cd backend && npm run dev; start frontend: cd frontend && npm run dev"
